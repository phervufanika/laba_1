package bsu;

public interface Consumable {
    public abstract void consume();

}
